﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace ASM2_QuanLyBHXH
{
    class GiaiDoanDong
    {
        public int ThangFrom { get; set; }
        public int NamFrom { get; set; }
        public int ThangTo { get; set; }
        public int NamTo { get; set; }
        public double LuongDong { get; set; } // lương 1 tháng

        public int SoThang()
        {
            return (NamTo - NamFrom) * 12 + (ThangTo - ThangFrom) + 1;
        }

        public double TongTienDong()
        {
            return SoThang() * LuongDong;
        }

        public override string ToString()
        {
            return $"Từ {ThangFrom}/{NamFrom} đến {ThangTo}/{NamTo}, lương: {LuongDong:N0}, " +
                   $"tháng: {SoThang()}, tổng: {TongTienDong():N0}";
        }
    }

    class NguoiLaoDong
    {
        public string MaBHXH { get; set; }      // 10 ký tự số
        public string HoTen { get; set; }
        public string GioiTinh { get; set; }    // Nam / Nữ
        public DateTime NgaySinh { get; set; }

        public List<GiaiDoanDong> DsGiaiDoan { get; set; } = new List<GiaiDoanDong>();

        public int TongSoThangDong()
        {
            int tong = 0;
            foreach (var g in DsGiaiDoan)
                tong += g.SoThang();
            return tong;
        }

        public double TongTienDong()
        {
            double tong = 0;
            foreach (var g in DsGiaiDoan)
                tong += g.TongTienDong();
            return tong;
        }

        private double ChuyenThangThanhNam(int soThang)
        {
            int namTron = soThang / 12;
            int thangLe = soThang % 12;
            double nam = namTron;

            if (thangLe >= 1 && thangLe <= 6) nam += 0.5;
            else if (thangLe >= 7) nam += 1;

            return nam;
        }

        // Tính BHXH 1 lần theo công thức trong tài liệu tham khảo
        public double TinhBHXH1Lan()
        {
            int tongThang = TongSoThangDong();
            if (tongThang == 0) return 0;

            double mbq = TongTienDong() / tongThang;   // mức bình quân tiền lương tháng

            // tách số tháng trước 2014 và từ 2014 trở đi
            int thangTruoc2014 = 0;
            int thangTu2014 = 0;
            int chiSoDec2013 = 2013 * 12 + 12; // 12/2013

            foreach (var g in DsGiaiDoan)
            {
                int start = g.NamFrom * 12 + g.ThangFrom;
                int end = g.NamTo * 12 + g.ThangTo;
                int soThangGiaiDoan = g.SoThang();

                int thangTruoc = 0;
                if (start <= chiSoDec2013)
                {
                    int endTruoc = Math.Min(end, chiSoDec2013);
                    thangTruoc = endTruoc - start + 1;
                    if (thangTruoc < 0) thangTruoc = 0;
                }

                int thangSau = soThangGiaiDoan - thangTruoc;

                thangTruoc2014 += thangTruoc;
                thangTu2014 += thangSau;
            }

            double soNamTruoc2014 = ChuyenThangThanhNam(thangTruoc2014);
            double soNamTu2014 = ChuyenThangThanhNam(thangTu2014);

            // Mức hưởng = Mbqtl × [1.5 × năm trước 2014 + 2 × năm từ 2014 trở đi]
            double mucHuong = mbq * (1.5 * soNamTruoc2014 + 2 * soNamTu2014);
            return mucHuong;
        }

        public override string ToString()
        {
            return $"Mã BHXH: {MaBHXH} | Họ tên: {HoTen} | Giới tính: {GioiTinh} | " +
                   $"Ngày sinh: {NgaySinh:dd/MM/yyyy}";
        }
    }

    class Program
    {
        static List<NguoiLaoDong> dsNguoi = new List<NguoiLaoDong>();

        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            while (true)
            {
                Console.WriteLine("\n===== MENU QUẢN LÝ THÔNG TIN BHXH =====");
                Console.WriteLine("1. Thêm mới một người lao động");
                Console.WriteLine("2. Thêm các giai đoạn đóng BHXH cho người lao động");
                Console.WriteLine("3. Xuất danh sách người lao động, thống kê Nam / Nữ");
                Console.WriteLine("4. Danh sách người có tham gia BHXH và tổng số tiền đã đóng");
                Console.WriteLine("5. Tính tiền BHXH 1 lần cho người lao động tham gia BHXH");
                Console.WriteLine("0. Thoát");
                Console.Write("Chọn chức năng: ");

                string chon = Console.ReadLine();
                switch (chon)
                {
                    case "1":
                        ThemNguoiLaoDong();
                        break;
                    case "2":
                        ThemGiaiDoanDong();
                        break;
                    case "3":
                        XuatDanhSachVaThongKe();
                        break;
                    case "4":
                        XuatNguoiCoDongBHXH();
                        break;
                    case "5":
                        TinhBHXH1LanChoTatCa();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ.");
                        break;
                }
            }
        }

        // 1. Thêm mới người lao động
        static void ThemNguoiLaoDong()
        {
            Console.WriteLine("\n--- Thêm người lao động ---");

            string ma;
            while (true)
            {
                Console.Write("Nhập mã số BHXH (10 ký tự số): ");
                ma = Console.ReadLine();

                if (ma.Length == 10 && long.TryParse(ma, out _))
                {
                    bool trung = dsNguoi.Exists(n => n.MaBHXH == ma);
                    if (trung)
                    {
                        Console.WriteLine("Mã BHXH đã tồn tại, nhập lại.");
                    }
                    else break;
                }
                else
                {
                    Console.WriteLine("Mã không hợp lệ, phải gồm 10 chữ số.");
                }
            }

            Console.Write("Họ tên: ");
            string hoTen = Console.ReadLine();

            string gioiTinh;
            while (true)
            {
                Console.Write("Giới tính (Nam/Nữ): ");
                gioiTinh = Console.ReadLine().Trim();
                if (gioiTinh.Equals("Nam", StringComparison.OrdinalIgnoreCase) ||
                    gioiTinh.Equals("Nữ", StringComparison.OrdinalIgnoreCase) ||
                    gioiTinh.Equals("Nu", StringComparison.OrdinalIgnoreCase))
                {
                    if (gioiTinh.Equals("Nu", StringComparison.OrdinalIgnoreCase))
                        gioiTinh = "Nữ";
                    break;
                }
                Console.WriteLine("Nhập lại, chỉ Nam hoặc Nữ.");
            }

            DateTime ngaySinh;
            while (true)
            {
                Console.Write("Ngày sinh (dd/MM/yyyy): ");
                if (DateTime.TryParseExact(Console.ReadLine(), "dd/MM/yyyy",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out ngaySinh))
                    break;
                Console.WriteLine("Định dạng ngày không đúng, nhập lại.");
            }

            var nguoi = new NguoiLaoDong
            {
                MaBHXH = ma,
                HoTen = hoTen,
                GioiTinh = gioiTinh,
                NgaySinh = ngaySinh
            };

            dsNguoi.Add(nguoi);
            Console.WriteLine(">> Thêm người lao động thành công.");
        }

        // 2. Thêm các giai đoạn đóng BHXH cho 1 người
        static void ThemGiaiDoanDong()
        {
            Console.WriteLine("\n--- Thêm giai đoạn đóng BHXH ---");
            Console.Write("Nhập mã số BHXH: ");
            string ma = Console.ReadLine();

            var nguoi = dsNguoi.Find(n => n.MaBHXH == ma);
            if (nguoi == null)
            {
                Console.WriteLine("Không tìm thấy người lao động có mã này.");
                return;
            }

            Console.WriteLine("Thông tin người lao động:");
            Console.WriteLine(nguoi);

            int k;
            while (true)
            {
                Console.Write("Nhập số giai đoạn K (>0): ");
                if (int.TryParse(Console.ReadLine(), out k) && k > 0) break;
                Console.WriteLine("K phải là số nguyên dương.");
            }

            for (int i = 1; i <= k; i++)
            {
                Console.WriteLine($"\nGiai đoạn thứ {i}:");

                int thangFrom, namFrom, thangTo, namTo;
                while (true)
                {
                    thangFrom = NhapSoNguyen("  Tháng bắt đầu (1-12): ", 1, 12);
                    namFrom = NhapSoNguyen("  Năm bắt đầu: ", 1900, 2100);

                    thangTo = NhapSoNguyen("  Tháng kết thúc (1-12): ", 1, 12);
                    namTo = NhapSoNguyen("  Năm kết thúc: ", 1900, 2100);

                    int start = namFrom * 12 + thangFrom;
                    int end = namTo * 12 + thangTo;

                    if (start > end)
                    {
                        Console.WriteLine("  Thời gian không hợp lệ (từ > đến), nhập lại.");
                        continue;
                    }

                    bool trungLap = false;
                    foreach (var g in nguoi.DsGiaiDoan)
                    {
                        int s = g.NamFrom * 12 + g.ThangFrom;
                        int e = g.NamTo * 12 + g.ThangTo;
                        if (!(end < s || start > e))
                        {
                            trungLap = true;
                            break;
                        }
                    }

                    if (trungLap)
                        Console.WriteLine("  Giai đoạn này trùng với giai đoạn đã có, nhập lại.");
                    else
                        break;
                }

                double luong;
                while (true)
                {
                    Console.Write("  Mức lương đóng BHXH (1 tháng): ");
                    if (double.TryParse(Console.ReadLine(), out luong) && luong > 0) break;
                    Console.WriteLine("  Lương phải > 0.");
                }

                var giaiDoan = new GiaiDoanDong
                {
                    ThangFrom = thangFrom,
                    NamFrom = namFrom,
                    ThangTo = thangTo,
                    NamTo = namTo,
                    LuongDong = luong
                };

                nguoi.DsGiaiDoan.Add(giaiDoan);
                Console.WriteLine("  >> Thêm giai đoạn thành công.");
            }
        }

        static int NhapSoNguyen(string msg, int min, int max)
        {
            int x;
            while (true)
            {
                Console.Write(msg);
                if (int.TryParse(Console.ReadLine(), out x) && x >= min && x <= max)
                    return x;
                Console.WriteLine($"  Giá trị phải trong khoảng {min}..{max}");
            }
        }

        // 3. Xuất danh sách + thống kê Nam / Nữ
        static void XuatDanhSachVaThongKe()
        {
            Console.WriteLine("\n--- Danh sách người lao động ---");
            if (dsNguoi.Count == 0)
            {
                Console.WriteLine("Chưa có dữ liệu.");
                return;
            }

            int soNam = 0, soNu = 0;
            foreach (var n in dsNguoi)
            {
                Console.WriteLine(n);
                if (n.GioiTinh.Equals("Nam", StringComparison.OrdinalIgnoreCase))
                    soNam++;
                else
                    soNu++;
            }

            Console.WriteLine($"\nTổng số người: {dsNguoi.Count}");
            Console.WriteLine($"Số lao động Nam: {soNam}");
            Console.WriteLine($"Số lao động Nữ: {soNu}");
        }

        // 4. Danh sách người có tham gia BHXH và tổng tiền đã đóng
        static void XuatNguoiCoDongBHXH()
        {
            Console.WriteLine("\n--- Người lao động có tham gia BHXH ---");
            bool co = false;
            foreach (var n in dsNguoi)
            {
                if (n.DsGiaiDoan.Count > 0)
                {
                    co = true;
                    Console.WriteLine("\n" + n);
                    Console.WriteLine("  Các giai đoạn đóng:");
                    foreach (var g in n.DsGiaiDoan)
                        Console.WriteLine("  - " + g);
                    Console.WriteLine($"  >> Tổng số tiền đã đóng: {n.TongTienDong():N0}");
                }
            }

            if (!co)
                Console.WriteLine("Chưa có ai có thông tin đóng BHXH.");
        }

        // 5. Tính BHXH 1 lần cho tất cả người có tham gia
        static void TinhBHXH1LanChoTatCa()
        {
            Console.WriteLine("\n--- Tính tiền BHXH 1 lần ---");
            bool co = false;

            foreach (var n in dsNguoi)
            {
                if (n.DsGiaiDoan.Count == 0) continue;

                co = true;
                double tien1Lan = n.TinhBHXH1Lan();
                Console.WriteLine("\n" + n);
                Console.WriteLine($"  Tổng số tháng đã đóng: {n.TongSoThangDong()}");
                Console.WriteLine($"  Tổng tiền lương đã đóng (chưa điều chỉnh): {n.TongTienDong():N0}");
                Console.WriteLine($"  >> Ước tính BHXH 1 lần theo công thức 2024: {tien1Lan:N0}");
            }

            if (!co)
                Console.WriteLine("Chưa có dữ liệu giai đoạn đóng BHXH để tính.");
        }
    }
}
